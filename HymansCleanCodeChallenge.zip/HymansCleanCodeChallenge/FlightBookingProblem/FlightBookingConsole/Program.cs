﻿using System;
using FlightBooking.Core;

namespace FlightBookingProblem
{
    class Program
    {
        private static ScheduledFlight _scheduledFlight;
        static void Main(string[] args)
        {
            SetupAirlineData();
            _scheduledFlight.Rule.IsRuleRelaxed = true;

            string command = "";
            try
            {
                do
                {
                    command = Console.ReadLine() ?? "";
                    var enteredText = command.ToLower();
                    if (enteredText.Contains("print summary"))
                    {
                        Console.WriteLine();
                        Console.WriteLine(_scheduledFlight.GetSummary());
                    }
                    else if (enteredText.Contains("add general"))
                    {
                        string[] passengerSegments = enteredText.Split(' ');
                        _scheduledFlight.AddPassenger(new Passenger
                        {
                            Type = PassengerType.General,
                            Name = passengerSegments[2],
                            Age = Convert.ToInt32(passengerSegments[3])
                        });
                    }
                    else if (enteredText.Contains("add loyalty"))
                    {
                        string[] passengerSegments = enteredText.Split(' ');
                        _scheduledFlight.AddPassenger(new Passenger
                        {
                            Type = PassengerType.LoyaltyMember,
                            Name = passengerSegments[2],
                            Age = Convert.ToInt32(passengerSegments[3]),
                            LoyaltyPoints = Convert.ToInt32(passengerSegments[4]),
                            IsUsingLoyaltyPoints = Convert.ToBoolean(passengerSegments[5]),
                        });
                    }
                    else if (enteredText.Contains("add airline"))
                    {
                        string[] passengerSegments = enteredText.Split(' ');
                        _scheduledFlight.AddPassenger(new Passenger
                        {
                            Type = PassengerType.AirlineEmployee,
                            Name = passengerSegments[2],
                            Age = Convert.ToInt32(passengerSegments[3]),
                        });
                    }

                    else if (enteredText.Contains("add discount"))
                    {
                        string[] passengerSegments = enteredText.Split(' ');
                        _scheduledFlight.AddPassenger(_scheduledFlight.
                            CreateDiscountPassengerInstance(passengerSegments));
                    }
                    else if (enteredText.Contains("exit"))
                    {
                        Environment.Exit(1);
                    }
                    else
                    {
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine("UNKNOWN INPUT");
                        Console.ResetColor();
                    }
                } while (command != "exit");
            }
            catch (Exception ex)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("WRONG INPUT");
            }
        }

        private static void SetupAirlineData()
        {
            FlightRoute londonToParis = new FlightRoute("London", "Paris")
            {
                BaseCost = 50,
                BasePrice = 100,
                LoyaltyPointsGained = 5,
                MinimumTakeOffPercentage = 0.7
            };

            _scheduledFlight = new ScheduledFlight(londonToParis);

            //adding flight to the list
            _scheduledFlight.AddToAircraftsList(
                new Plane { Id = 123, Name = "Antonov AN-12", NumberOfSeats = 12 });
            _scheduledFlight.SetAircraftForRoute(_scheduledFlight.Aircrafts[0]);
            _scheduledFlight.AddToAircraftsList(
                new Plane { Id = 234, Name = "Boeing 787", NumberOfSeats = 142 });
            _scheduledFlight.AddToAircraftsList(
                new Plane { Id = 345, Name = "Antonov AN-14", NumberOfSeats = 14 });
            _scheduledFlight.AddToAircraftsList(
                new Plane { Id = 456, Name = "Antonov AN-18", NumberOfSeats = 18 });
        }
    }
}
