﻿using System;
using System.Linq;
using System.Collections.Generic;
using System.Text;
using System.Diagnostics;
using System.Runtime.InteropServices.WindowsRuntime;

namespace FlightBooking.Core
{
    public class ScheduledFlight
    {
        private readonly string VERTICAL_WHITE_SPACE = Environment.NewLine + Environment.NewLine;
        private readonly string NEW_LINE = Environment.NewLine;
        private const string INDENTATION = "    ";

        public ScheduledFlight(FlightRoute flightRoute)
        {
            FlightRoute = flightRoute;
            Passengers = new List<Passenger>();
            Rule = new RuleSet();
        }

        public FlightRoute FlightRoute { get; private set; }
        public Plane Aircraft { get; private set; }
        public List<Plane> Aircrafts { get; private set; } = new List<Plane>();
        public List<Passenger> Passengers { get; private set; }
        public RuleSet Rule { get; private set; }

        public void AddPassenger(Passenger passenger)
        {
            Passengers.Add(passenger);
        }

        public void SetAircraftForRoute(Plane aircraft)
        {
            Aircraft = aircraft;
        }

        public void AddToAircraftsList(Plane aircraft)
        {
            Aircrafts.Add(aircraft);
        }

        /// <summary>
        /// GetSummary has got the control by the management to decide which flight to function.
        /// So allowing them to decide wheather new rule implementation or the old one.
        /// Later old implementation can be scrapped
        /// In future more rules can be added too.
        /// </summary>
        /// <param name="flightTakeOffNewImplementation"> decides new or old implementation </param>
        /// <returns> string </returns>
        public string GetSummary()
        {
            double costOfFlight = 0;
            double profitFromFlight = 0;
            int totalLoyaltyPointsAccrued = 0;
            int totalLoyaltyPointsRedeemed = 0;
            int totalExpectedBaggage = 0;
            int seatsTaken = 0;


            StringBuilder result = new StringBuilder();
            result.AppendLine("Flight summary for " + FlightRoute.Title);

            foreach (var passenger in Passengers)
            {
                switch (passenger.Type)
                {
                    case (PassengerType.General):
                        {
                            profitFromFlight += FlightRoute.BasePrice;
                            totalExpectedBaggage++;
                            break;
                        }
                    case (PassengerType.LoyaltyMember):
                        {
                            if (passenger.IsUsingLoyaltyPoints)
                            {
                                int loyaltyPointsRedeemed = Convert.ToInt32(Math.Ceiling(FlightRoute.BasePrice));
                                passenger.LoyaltyPoints -= loyaltyPointsRedeemed;
                                totalLoyaltyPointsRedeemed += loyaltyPointsRedeemed;
                            }
                            else
                            {
                                totalLoyaltyPointsAccrued += FlightRoute.LoyaltyPointsGained;
                                profitFromFlight += FlightRoute.BasePrice;
                            }
                            totalExpectedBaggage += 2;
                            break;
                        }
                    case (PassengerType.DiscountedMember):
                        {

                            profitFromFlight += FlightRoute.BasePrice * .5;
                            totalExpectedBaggage = 0;

                            break;
                        }
                    case (PassengerType.AirlineEmployee):
                        {
                            totalExpectedBaggage += 1;
                            break;
                        }
                }
                costOfFlight += FlightRoute.BaseCost;
                seatsTaken++;
            }

            //for better memory management used stringbuilder instead of string.
            #region SUMMARY

            result.Append(VERTICAL_WHITE_SPACE);

            result.Append("Total passengers: " + seatsTaken);
            result.Append(NEW_LINE);
            result.Append(INDENTATION + "General sales: " + Passengers.Count(p => p.Type == PassengerType.General));
            result.Append(NEW_LINE);
            result.Append(INDENTATION + "Loyalty member sales: " + Passengers.Count(p => p.Type == PassengerType.LoyaltyMember));
            result.Append(NEW_LINE);
            result.Append(INDENTATION + "Airline employee comps: " + Passengers.Count(p => p.Type == PassengerType.AirlineEmployee));

            result.Append(VERTICAL_WHITE_SPACE);
            result.Append("Total expected baggage: " + totalExpectedBaggage);

            result.Append(VERTICAL_WHITE_SPACE);

            result.Append("Total revenue from flight: " + profitFromFlight);
            result.Append(NEW_LINE);
            result.Append("Total costs from flight: " + costOfFlight);
            result.Append(NEW_LINE);

            double profitSurplus = profitFromFlight - costOfFlight;

            result.Append((profitSurplus > 0 ? "Flight generating profit of: " : "Flight losing money of: ") + profitSurplus);

            result.Append(VERTICAL_WHITE_SPACE);

            result.Append("Total loyalty points given away: " + totalLoyaltyPointsAccrued + NEW_LINE);
            result.Append("Total loyalty points redeemed: " + totalLoyaltyPointsRedeemed + NEW_LINE);

            result.Append(VERTICAL_WHITE_SPACE);

            #endregion SUMMARY

            //created a bool variable to cancel the alternate flight check.
            bool isAllBusinessConditionSuccessCheck = true;
            if (Rule.IsOldImplementation)
            {
                FightTakeOffGeneralCheck(seatsTaken, result, profitSurplus);
                return result.ToString();
            }
            else
                FightTakeOffDiscountUserAndNewRuleCheck(seatsTaken, result, profitSurplus, ref isAllBusinessConditionSuccessCheck);

            // if any of a business condition is already failed need not the check the flight change condition.
            if (isAllBusinessConditionSuccessCheck && Rule.IsDecideFilghtChange)
            {
                if (seatsTaken > Aircraft.NumberOfSeats)
                {
                    var altFlight = Aircrafts.Where(a => a.Id != Aircraft.Id && a.NumberOfSeats >= seatsTaken).ToList();

                    int counter = 0;
                    foreach (var flight in altFlight)
                    {
                        if (counter == 0)
                            result.AppendLine("Other more suitable aircraft are:");
                        result.AppendLine($"{flight.Name} could handle this flight.");
                        counter = 1;
                    }
                }
            }

            return result.ToString();
        }

        private void FightTakeOffGeneralCheck(int seatsTaken, StringBuilder result, double profitSurplus)
        {
            if (profitSurplus > 0 &&
                seatsTaken < Aircraft.NumberOfSeats &&
                seatsTaken / (double)Aircraft.NumberOfSeats > FlightRoute.MinimumTakeOffPercentage)
                result.AppendLine("THIS FLIGHT MAY PROCEED");
            else
                result.AppendLine("FLIGHT MAY NOT PROCEED");

        }

        private void FightTakeOffDiscountUserAndNewRuleCheck(int seatsTaken, StringBuilder result, double profitSurplus, ref bool isAllBusinessConditionSuccessCheck)
        {
            if (RuleSeatsBookedGreaterThanMinimumPercentage(seatsTaken, ref isAllBusinessConditionSuccessCheck)
                && RuleProfitGreaterThanBaseCost(profitSurplus, ref isAllBusinessConditionSuccessCheck) && (seatsTaken <= Aircraft.NumberOfSeats))
                result.AppendLine("THIS FLIGHT MAY PROCEED");
            else
                result.AppendLine("FLIGHT MAY NOT PROCEED");
        }

        private bool RuleSeatsBookedGreaterThanMinimumPercentage(int seatsTaken, ref bool isAllBusinessConditionSuccessCheck)
        {
            bool isSuccess = false;
            if (Rule.IsRuleRelaxed)
            {
                isSuccess = true;
            }
            else
            {
                if (seatsTaken / (double)Aircraft.NumberOfSeats > FlightRoute.MinimumTakeOffPercentage)
                    isSuccess = true;

                else
                    isSuccess = false;
            }
            isAllBusinessConditionSuccessCheck = (isAllBusinessConditionSuccessCheck) ? isSuccess : false;
            return isSuccess;
        }
        private bool RuleProfitGreaterThanBaseCost(double profitSurplus, ref bool isAllBusinessConditionSuccessCheck)
        {
            bool isSuccess = false;
            if (Rule.IsRuleRelaxed && Passengers.Count(a => a.Type == PassengerType.AirlineEmployee) /
                    (double)Aircraft.NumberOfSeats > FlightRoute.MinimumTakeOffPercentage)
            {
                isSuccess = true;
            }
            else
            {
                if (profitSurplus > FlightRoute.BaseCost)
                    isSuccess = true;
                else
                    isSuccess = false;
            }
            isAllBusinessConditionSuccessCheck = (isAllBusinessConditionSuccessCheck) ? isSuccess : false;
            return isSuccess;
        }



        public Passenger CreateDiscountPassengerInstance(string[] passengerSegments)
        {
            Passenger discPassenger = new Passenger();
            try
            {
                discPassenger.Name = passengerSegments[2];
                discPassenger.AllowedBags = 0;
                discPassenger.IsUsingLoyaltyPoints = false;
                return discPassenger;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
