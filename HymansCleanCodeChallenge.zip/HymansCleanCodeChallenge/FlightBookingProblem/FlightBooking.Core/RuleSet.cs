﻿using System.Collections.Generic;

namespace FlightBooking.Core
{
    //new properties can be added as and when new rules are added.
    public sealed class RuleSet
    {
        public bool IsOldImplementation { get; set; }=false;
        public bool IsRuleRelaxed { get; set; } = false;
        public bool IsDecideFilghtChange { get; set; }=true;

    }

}
