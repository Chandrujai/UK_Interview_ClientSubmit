﻿using FlightBooking.Core;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FlightBooking.CoreTests.Mock
{
    internal class MockData
    {
        public List<Passenger> passengers = new List<Passenger>();
        public ScheduledFlight _mockScheduledFlight;
        public FlightRoute _flightRoute;

        public void FileInputs()
        {
            FlightRoute londonToParis = new FlightRoute("London", "Paris")
            {
                BaseCost = 50,
                BasePrice = 100,
                LoyaltyPointsGained = 5,
                MinimumTakeOffPercentage = 0.7
            };


            _mockScheduledFlight = new ScheduledFlight(londonToParis);

            _mockScheduledFlight.AddToAircraftsList(
                new Plane { Id = 123, Name = "Antonov AN-2", NumberOfSeats = 12 });

            _mockScheduledFlight.SetAircraftForRoute(_mockScheduledFlight.Aircrafts[0]);

            _mockScheduledFlight.AddToAircraftsList(
                new Plane { Id = 234, Name = "Bombardier Q400", NumberOfSeats = 22 });

            _mockScheduledFlight.AddToAircraftsList(
                new Plane { Id = 345, Name = "ATR 640", NumberOfSeats = 18 });

            _mockScheduledFlight.Rule.IsOldImplementation = false;
            _mockScheduledFlight.Rule.IsRuleRelaxed = true;
            _mockScheduledFlight.Rule.IsDecideFilghtChange = true;

            _mockScheduledFlight.AddPassenger(new Passenger()
            {
                Name = "Steve",
                Age = 30,
                Type = PassengerType.General
            });
            _mockScheduledFlight.AddPassenger(new Passenger()
            {
                Name = "Mark",
                Age = 12,
                Type = PassengerType.General
            });
            _mockScheduledFlight.AddPassenger(new Passenger()
            {
                Name = "James",
                Age = 36,
                Type = PassengerType.General
            });
            _mockScheduledFlight.AddPassenger(new Passenger()
            {
                Name = "Jane",
                Age = 32,
                Type = PassengerType.General
            });
            _mockScheduledFlight.AddPassenger(new Passenger()
            {
                Name = "John",
                Age = 29,
                LoyaltyPoints = 1000,
                IsUsingLoyaltyPoints = true,
                Type = PassengerType.LoyaltyMember
            });
            _mockScheduledFlight.AddPassenger(new Passenger()
            {
                Name = "Sarah",
                Age = 45,
                LoyaltyPoints = 1250,
                IsUsingLoyaltyPoints = false,
                Type = PassengerType.LoyaltyMember
            });
            _mockScheduledFlight.AddPassenger(new Passenger()
            {
                Name = "Jack",
                Age = 50,
                LoyaltyPoints = 60,
                IsUsingLoyaltyPoints = false,
                Type = PassengerType.LoyaltyMember
            });
            _mockScheduledFlight.AddPassenger(new Passenger()
            {
                Name = "Trevor",
                Age = 47,
                Type = PassengerType.AirlineEmployee
            });
            _mockScheduledFlight.AddPassenger(new Passenger()
            {
                Name = "Alan",
                Age = 34,
                Type = PassengerType.General
            });
            _mockScheduledFlight.AddPassenger(new Passenger()
            {
                Name = "Suzy",
                Age = 21,
                Type = PassengerType.General
            });
        }
    }
}
