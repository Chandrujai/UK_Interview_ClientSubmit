﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using FlightBooking.Core;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Moq;
using FlightBooking.CoreTests.Mock;

namespace FlightBooking.Core.Tests
{
    [TestClass()]
    public class ScheduledFlightTests
    {
        private static ScheduledFlight _scheduledFlight;

        public ScheduledFlightTests()
        {
            MockData moqData = new MockData();
            moqData.FileInputs();
            _scheduledFlight = moqData._mockScheduledFlight;
        }

        [TestMethod()]
        public void GetSummaryTest_OldImplementation()
        {
            _scheduledFlight.Rule.IsOldImplementation = true;
            var result = _scheduledFlight.GetSummary();
            Assert.AreEqual("Flight summary for London to Paris\r\n\r\n\r\nTotal passengers: 10\r\n    General sales: 6\r\n    Loyalty member sales: 3\r\n    Airline employee comps: 1\r\n\r\nTotal expected baggage: 13\r\n\r\nTotal revenue from flight: 800\r\nTotal costs from flight: 500\r\nFlight generating profit of: 300\r\n\r\nTotal loyalty points given away: 10\r\nTotal loyalty points redeemed: 100\r\n\r\n\r\nTHIS FLIGHT MAY PROCEED\r\n", result);
        }

        [TestMethod()]
        public void GetSummaryTest_NewImplementationGoodToGo()
        {
            _scheduledFlight.Rule.IsOldImplementation = false;
            var result = _scheduledFlight.GetSummary();
            Assert.AreEqual("Flight summary for London to Paris\r\n\r\n\r\nTotal passengers: 10\r\n    General sales: 6\r\n    Loyalty member sales: 3\r\n    Airline employee comps: 1\r\n\r\nTotal expected baggage: 13\r\n\r\nTotal revenue from flight: 800\r\nTotal costs from flight: 500\r\nFlight generating profit of: 300\r\n\r\nTotal loyalty points given away: 10\r\nTotal loyalty points redeemed: 100\r\n\r\n\r\nTHIS FLIGHT MAY PROCEED\r\n", result);
        }

        [TestMethod()]
        public void GetSummaryTest_NewImplementationChooseDifferentFlight()
        {
            _scheduledFlight.Rule.IsOldImplementation = false;
            _scheduledFlight.Aircrafts[0].NumberOfSeats = 4;
            _scheduledFlight.Aircraft.NumberOfSeats = 4;

            var result = _scheduledFlight.GetSummary();
            Assert.AreEqual("Flight summary for London to Paris\r\n\r\n\r\nTotal passengers: 10\r\n    General sales: 6\r\n    Loyalty member sales: 3\r\n    Airline employee comps: 1\r\n\r\nTotal expected baggage: 13\r\n\r\nTotal revenue from flight: 800\r\nTotal costs from flight: 500\r\nFlight generating profit of: 300\r\n\r\nTotal loyalty points given away: 10\r\nTotal loyalty points redeemed: 100\r\n\r\n\r\nFLIGHT MAY NOT PROCEED\r\nOther more suitable aircraft are:\r\nBombardier Q400 could handle this flight.\r\nATR 640 could handle this flight.\r\n", result);
        }

        [TestMethod()]
        public void GetSummaryTest_NewImplementationDontChooseDifferentFlight()
        {
            _scheduledFlight.Rule.IsOldImplementation = false;
            _scheduledFlight.Rule.IsDecideFilghtChange = false;
            _scheduledFlight.Aircrafts[0].NumberOfSeats = 4;
            _scheduledFlight.Aircraft.NumberOfSeats = 4;

            var result = _scheduledFlight.GetSummary();
            Assert.AreEqual("Flight summary for London to Paris\r\n\r\n\r\nTotal passengers: 10\r\n    General sales: 6\r\n    Loyalty member sales: 3\r\n    Airline employee comps: 1\r\n\r\nTotal expected baggage: 13\r\n\r\nTotal revenue from flight: 800\r\nTotal costs from flight: 500\r\nFlight generating profit of: 300\r\n\r\nTotal loyalty points given away: 10\r\nTotal loyalty points redeemed: 100\r\n\r\n\r\nFLIGHT MAY NOT PROCEED\r\n", result);
        }

        [TestMethod()]
        public void GetSummaryTest_EmployeeCountLesserThanMinPercentageFlightNotProceed()

        {
            _scheduledFlight.Rule.IsOldImplementation = false;
            _scheduledFlight.Passengers[0].Type = PassengerType.AirlineEmployee;
            _scheduledFlight.Passengers[1].Type = PassengerType.AirlineEmployee;
            _scheduledFlight.Passengers[2].Type = PassengerType.AirlineEmployee;
            _scheduledFlight.Passengers[3].Type = PassengerType.AirlineEmployee;
            _scheduledFlight.FlightRoute.MinimumTakeOffPercentage = 100;

            var result = _scheduledFlight.GetSummary();
            Assert.AreEqual("Flight summary for London to Paris\r\n\r\n\r\nTotal passengers: 10\r\n    General sales: 2\r\n    Loyalty member sales: 3\r\n    Airline employee comps: 5\r\n\r\nTotal expected baggage: 13\r\n\r\nTotal revenue from flight: 400\r\nTotal costs from flight: 500\r\nFlight losing money of: -100\r\n\r\nTotal loyalty points given away: 10\r\nTotal loyalty points redeemed: 100\r\n\r\n\r\nFLIGHT MAY NOT PROCEED\r\n", result);
        }

        [TestMethod()]
        public void GetSummaryTest_NewImplementationDiscountedPassengerDontFly()
        {
            _scheduledFlight.Rule.IsOldImplementation = false;
            _scheduledFlight.Rule.IsDecideFilghtChange = false;
            _scheduledFlight.AddPassenger(new Passenger()
            {
                Name = "Jai",
                Age = 40,
                Type = PassengerType.DiscountedMember
            });
            _scheduledFlight.AddPassenger(new Passenger()
            {
                Name = "Chandran",
                Age = 40,
                Type = PassengerType.DiscountedMember
            });
            _scheduledFlight.FlightRoute.BaseCost = 100;

            var result = _scheduledFlight.GetSummary();
            Assert.AreEqual("Flight summary for London to Paris\r\n\r\n\r\nTotal passengers: 12\r\n    General sales: 6\r\n    Loyalty member sales: 3\r\n    Airline employee comps: 1\r\n\r\nTotal expected baggage: 0\r\n\r\nTotal revenue from flight: 900\r\nTotal costs from flight: 1200\r\nFlight losing money of: -300\r\n\r\nTotal loyalty points given away: 10\r\nTotal loyalty points redeemed: 100\r\n\r\n\r\nFLIGHT MAY NOT PROCEED\r\n", result);
        }

        [TestMethod()]
        public void GetSummaryTest_NewImplementationEmployeeCountDontCheckRevenue()
        {
            _scheduledFlight.Rule.IsOldImplementation = false;
            _scheduledFlight.Passengers[0].Type = PassengerType.AirlineEmployee;
            _scheduledFlight.Passengers[1].Type = PassengerType.AirlineEmployee;
            _scheduledFlight.Passengers[2].Type = PassengerType.AirlineEmployee;
            _scheduledFlight.Passengers[3].Type = PassengerType.AirlineEmployee;
            _scheduledFlight.Passengers[8].Type = PassengerType.AirlineEmployee;
            _scheduledFlight.Passengers[9].Type = PassengerType.AirlineEmployee;
            _scheduledFlight.Rule.IsDecideFilghtChange = false;

            _scheduledFlight.FlightRoute.BaseCost = 100;
            _scheduledFlight.FlightRoute.MinimumTakeOffPercentage = .2;

            var result = _scheduledFlight.GetSummary();
            Assert.AreEqual("Flight summary for London to Paris\r\n\r\n\r\nTotal passengers: 10\r\n    General sales: 0\r\n    Loyalty member sales: 3\r\n    Airline employee comps: 7\r\n\r\nTotal expected baggage: 13\r\n\r\nTotal revenue from flight: 200\r\nTotal costs from flight: 1000\r\nFlight losing money of: -800\r\n\r\nTotal loyalty points given away: 10\r\nTotal loyalty points redeemed: 100\r\n\r\n\r\nTHIS FLIGHT MAY PROCEED\r\n", result);
        }

        [TestMethod()]
        public void GetSummaryTest_NewImplementationEmployeeCountCheckRevenue()
        {
            _scheduledFlight.Rule.IsOldImplementation = false;
            _scheduledFlight.Rule.IsRuleRelaxed = false;
            _scheduledFlight.Passengers[0].Type = PassengerType.AirlineEmployee;
            _scheduledFlight.Passengers[1].Type = PassengerType.AirlineEmployee;
            _scheduledFlight.Passengers[2].Type = PassengerType.AirlineEmployee;
            _scheduledFlight.Passengers[3].Type = PassengerType.AirlineEmployee;
            _scheduledFlight.Passengers[8].Type = PassengerType.AirlineEmployee;
            _scheduledFlight.Passengers[9].Type = PassengerType.AirlineEmployee;
            _scheduledFlight.Rule.IsDecideFilghtChange = false;

            _scheduledFlight.FlightRoute.BaseCost = 100;
            _scheduledFlight.FlightRoute.MinimumTakeOffPercentage = .2;

            var result = _scheduledFlight.GetSummary();
            Assert.AreEqual("Flight summary for London to Paris\r\n\r\n\r\nTotal passengers: 10\r\n    General sales: 0\r\n    Loyalty member sales: 3\r\n    Airline employee comps: 7\r\n\r\nTotal expected baggage: 13\r\n\r\nTotal revenue from flight: 200\r\nTotal costs from flight: 1000\r\nFlight losing money of: -800\r\n\r\nTotal loyalty points given away: 10\r\nTotal loyalty points redeemed: 100\r\n\r\n\r\nFLIGHT MAY NOT PROCEED\r\n", result);
        }

        [TestMethod()]
        public void GetSummaryTest_EmployeeCountGreaterThanMinPercentageFlightProceed()
        {
            _scheduledFlight.Rule.IsOldImplementation = false;
            _scheduledFlight.Passengers[0].Type = PassengerType.AirlineEmployee;
            _scheduledFlight.Passengers[1].Type = PassengerType.AirlineEmployee;
            _scheduledFlight.Passengers[2].Type = PassengerType.AirlineEmployee;
            _scheduledFlight.Passengers[3].Type = PassengerType.AirlineEmployee;
            _scheduledFlight.Passengers[8].Type = PassengerType.AirlineEmployee;
            _scheduledFlight.Passengers[9].Type = PassengerType.AirlineEmployee;
            _scheduledFlight.Rule.IsDecideFilghtChange = false;

            _scheduledFlight.FlightRoute.BaseCost = 100;
            _scheduledFlight.FlightRoute.MinimumTakeOffPercentage = .2;

            var result = _scheduledFlight.GetSummary();
            Assert.AreEqual("Flight summary for London to Paris\r\n\r\n\r\nTotal passengers: 10\r\n    General sales: 0\r\n    Loyalty member sales: 3\r\n    Airline employee comps: 7\r\n\r\nTotal expected baggage: 13\r\n\r\nTotal revenue from flight: 200\r\nTotal costs from flight: 1000\r\nFlight losing money of: -800\r\n\r\nTotal loyalty points given away: 10\r\nTotal loyalty points redeemed: 100\r\n\r\n\r\nTHIS FLIGHT MAY PROCEED\r\n", result);
        }

        [TestMethod()]
        public void GetSummaryTest_NewImplementationDiscountedPassengerMayFly()
        {
            _scheduledFlight.Rule.IsOldImplementation = false;
            _scheduledFlight.AddPassenger(new Passenger()
            {
                Name = "Jai",
                Age = 40,
                Type = PassengerType.DiscountedMember
            });
            _scheduledFlight.AddPassenger(new Passenger()
            {
                Name = "Chandran",
                Age = 40,
                Type = PassengerType.DiscountedMember
            });

            var result = _scheduledFlight.GetSummary();
            Assert.AreEqual("Flight summary for London to Paris\r\n\r\n\r\nTotal passengers: 12\r\n    General sales: 6\r\n    Loyalty member sales: 3\r\n    Airline employee comps: 1\r\n\r\nTotal expected baggage: 0\r\n\r\nTotal revenue from flight: 900\r\nTotal costs from flight: 600\r\nFlight generating profit of: 300\r\n\r\nTotal loyalty points given away: 10\r\nTotal loyalty points redeemed: 100\r\n\r\n\r\nTHIS FLIGHT MAY PROCEED\r\n", result);
        }

        [TestMethod()]
        public void GetSummaryTest_NewImplementationNoOptionToChooseFlight()
        {
            _scheduledFlight.Rule.IsOldImplementation = false;
            _scheduledFlight.Aircrafts.RemoveRange(1, 2);
            _scheduledFlight.Aircrafts[0].NumberOfSeats = 4;
            _scheduledFlight.Aircraft.NumberOfSeats = 4;

            var result = _scheduledFlight.GetSummary();
            Assert.AreEqual("Flight summary for London to Paris\r\n\r\n\r\nTotal passengers: 10\r\n    General sales: 6\r\n    Loyalty member sales: 3\r\n    Airline employee comps: 1\r\n\r\nTotal expected baggage: 13\r\n\r\nTotal revenue from flight: 800\r\nTotal costs from flight: 500\r\nFlight generating profit of: 300\r\n\r\nTotal loyalty points given away: 10\r\nTotal loyalty points redeemed: 100\r\n\r\n\r\nFLIGHT MAY NOT PROCEED\r\n", result);
        }
    }
}